import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { 
  Calculator, 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Target,
  Clock,
  AlertTriangle,
  CheckCircle,
  Info,
  BarChart3,
  PieChart,
  Activity,
  Award,
  Zap,
  Coins,
  Handshake,
  Shield
} from "lucide-react"

interface TokenomicsData {
  symbol: string
  name: string
  currentPrice: number
  priceChange24h: number
  totalSupply: number
  circulatingSupply: number
  burnedSupply: number
  marketCap: number
  volume24h: number
  holders: number
  transactions24h: number
}

interface InvestmentCalculatorProps {
  tokenData: TokenomicsData
  onInvestmentChange?: (amount: number, tokens: number) => void
}

interface TokenUtilityProps {
  utilities: Array<{
    icon: React.ReactNode
    title: string
    description: string
    value: string
  }>
}

interface DeflationMechanismProps {
  burnRate: number
  totalBurned: number
  nextBurn: {
    amount: number
    condition: string
    estimatedDate: string
  }
}

export function InvestmentCalculator({ tokenData, onInvestmentChange }: InvestmentCalculatorProps) {
  const [investmentAmount, setInvestmentAmount] = useState(100)
  const [investmentType, setInvestmentType] = useState<'fixed' | 'recurring'>('fixed')
  
  const tokensToReceive = investmentAmount / tokenData.currentPrice
  const estimatedROI = tokenData.priceChange24h > 0 ? 
    ((investmentAmount * (1 + tokenData.priceChange24h / 100)) - investmentAmount) : 0
  
  const handleAmountChange = (amount: number) => {
    setInvestmentAmount(amount)
    onInvestmentChange?.(amount, tokensToReceive)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calculator className="h-5 w-5" />
          Investment Calculator
        </CardTitle>
        <CardDescription>
          Calculate your potential returns from investing in {tokenData.symbol}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Tabs value={investmentType} onValueChange={(value) => setInvestmentType(value as 'fixed' | 'recurring')}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="fixed">One-time Investment</TabsTrigger>
            <TabsTrigger value="recurring">Recurring Investment</TabsTrigger>
          </TabsList>
          
          <TabsContent value="fixed" className="space-y-4">
            <div>
              <Label htmlFor="amount">Investment Amount (USD)</Label>
              <div className="flex items-center gap-2 mt-2">
                <Input
                  id="amount"
                  type="number"
                  value={investmentAmount}
                  onChange={(e) => handleAmountChange(Number(e.target.value))}
                  min="10"
                  step="10"
                  className="flex-1"
                />
                <span className="text-sm text-slate-600 dark:text-slate-400">USD</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-sm text-slate-600 dark:text-slate-400">Tokens to Receive</Label>
                <p className="text-lg font-semibold">{tokensToReceive.toFixed(2)} {tokenData.symbol}</p>
              </div>
              <div>
                <Label className="text-sm text-slate-600 dark:text-slate-400">Current Price</Label>
                <p className="text-lg font-semibold">${tokenData.currentPrice}</p>
              </div>
            </div>
            
            <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm">Estimated ROI (24h)</span>
                <span className={`font-medium ${estimatedROI >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {estimatedROI >= 0 ? '+' : ''}{estimatedROI.toFixed(2)} USD
                </span>
              </div>
              <div className="flex justify-between items-center text-sm text-slate-600 dark:text-slate-400">
                <span>Based on 24h performance</span>
                <span className={`flex items-center gap-1 ${
                  tokenData.priceChange24h >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {tokenData.priceChange24h >= 0 ? (
                    <TrendingUp className="h-3 w-3" />
                  ) : (
                    <TrendingDown className="h-3 w-3" />
                  )}
                  {Math.abs(tokenData.priceChange24h)}%
                </span>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="recurring" className="space-y-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Recurring investments help you average your purchase price over time and reduce market timing risk.
              </AlertDescription>
            </Alert>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="monthly">Monthly Amount (USD)</Label>
                <Input
                  id="monthly"
                  type="number"
                  value={investmentAmount}
                  onChange={(e) => handleAmountChange(Number(e.target.value))}
                  min="10"
                  step="10"
                />
              </div>
              <div>
                <Label htmlFor="duration">Duration (months)</Label>
                <Input
                  id="duration"
                  type="number"
                  defaultValue="12"
                  min="1"
                  max="60"
                />
              </div>
            </div>
            
            <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm">Total Investment</span>
                <span className="font-medium">${(investmentAmount * 12).toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm">Estimated Tokens (Year)</span>
                <span className="font-medium">{(tokensToReceive * 12).toFixed(2)} {tokenData.symbol}</span>
              </div>
              <div className="flex justify-between items-center text-sm text-slate-600 dark:text-slate-400">
                <span>Monthly average</span>
                <span>{tokensToReceive.toFixed(2)} {tokenData.symbol}</span>
              </div>
            </div>
          </TabsContent>
        </Tabs>
        
        <Button className="w-full">
          Invest ${investmentAmount}
        </Button>
      </CardContent>
    </Card>
  )
}

export function TokenUtility({ utilities }: TokenUtilityProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5" />
          Token Utility
        </CardTitle>
        <CardDescription>
          Real-world applications and benefits of holding {utilities.length > 0 ? 'tokens' : 'the token'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {utilities.map((utility, index) => (
            <div key={index} className="flex items-start gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
              <div className="text-primary">
                {utility.icon}
              </div>
              <div className="flex-1">
                <h4 className="font-medium">{utility.title}</h4>
                <p className="text-sm text-slate-600 dark:text-slate-400 mb-1">
                  {utility.description}
                </p>
                <Badge variant="outline" className="text-xs">
                  {utility.value}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

export function DeflationMechanism({ burnRate, totalBurned, nextBurn }: DeflationMechanismProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Coins className="h-5 w-5" />
          Deflation Mechanism
        </CardTitle>
        <CardDescription>
          Built-in mechanisms to increase token value over time
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-red-600">{burnRate}%</div>
            <div className="text-sm text-slate-600 dark:text-slate-400">Transaction Burn Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{totalBurned.toLocaleString()}</div>
            <div className="text-sm text-slate-600 dark:text-slate-400">Total Tokens Burned</div>
          </div>
        </div>
        
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Every transaction on the platform burns {burnRate}% of the transaction fee, permanently reducing the total supply.
          </AlertDescription>
        </Alert>
        
        <div className="bg-orange-50 dark:bg-orange-900/20 rounded-lg p-4">
          <h4 className="font-medium mb-2">Next Scheduled Burn</h4>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span>Burn Amount:</span>
              <span className="font-medium">{nextBurn.amount.toLocaleString()} tokens</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Condition:</span>
              <span className="font-medium">{nextBurn.condition}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Estimated Date:</span>
              <span className="font-medium">{nextBurn.estimatedDate}</span>
            </div>
          </div>
        </div>
        
        <div className="space-y-3">
          <h4 className="font-medium">Burn Triggers</h4>
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Milestone achievements</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Volume thresholds reached</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Quarterly token burns</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

export function TokenMetrics({ tokenData }: { tokenData: TokenomicsData }) {
  const circulatingPercentage = (tokenData.circulatingSupply / tokenData.totalSupply) * 100
  const burnedPercentage = (tokenData.burnedSupply / tokenData.totalSupply) * 100
  
  return (
    <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Market Cap</p>
              <p className="text-2xl font-bold">${(tokenData.marketCap / 1000000).toFixed(1)}M</p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                ${tokenData.volume24h.toLocaleString()} 24h volume
              </p>
            </div>
            <BarChart3 className="h-8 w-8 text-blue-600" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Circulating Supply</p>
              <p className="text-2xl font-bold">{(tokenData.circulatingSupply / 1000).toFixed(1)}K</p>
              <div className="w-full bg-slate-200 rounded-full h-2 mt-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full" 
                  style={{ width: `${circulatingPercentage}%` }}
                ></div>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {circulatingPercentage.toFixed(1)}% of total
              </p>
            </div>
            <PieChart className="h-8 w-8 text-green-600" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Burned Tokens</p>
              <p className="text-2xl font-bold">{tokenData.burnedSupply.toLocaleString()}</p>
              <div className="w-full bg-slate-200 rounded-full h-2 mt-2">
                <div 
                  className="bg-red-600 h-2 rounded-full" 
                  style={{ width: `${burnedPercentage}%` }}
                ></div>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                {burnedPercentage.toFixed(1)}% burned
              </p>
            </div>
            <Coins className="h-8 w-8 text-red-600" />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-600 dark:text-slate-400">Token Holders</p>
              <p className="text-2xl font-bold">{tokenData.holders.toLocaleString()}</p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                {tokenData.transactions24h} transactions today
              </p>
            </div>
            <Users className="h-8 w-8 text-purple-600" />
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export function VestingSchedule() {
  const vestingPeriods = [
    { phase: "Initial Lock", duration: "6 months", percentage: 100, status: "active" },
    { phase: "Cliff Period", duration: "6 months", percentage: 100, status: "upcoming" },
    { phase: "Linear Vesting", duration: "24 months", percentage: 0, status: "pending" },
    { phase: "Fully Vested", duration: "Ongoing", percentage: 0, status: "pending" }
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Vesting Schedule
        </CardTitle>
        <CardDescription>
          Token release schedule to ensure long-term commitment
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert>
          <Shield className="h-4 w-4" />
          <AlertDescription>
            Tokens are subject to a 36-month vesting period with a 12-month cliff to ensure long-term commitment from talent.
          </AlertDescription>
        </Alert>
        
        <div className="space-y-4">
          {vestingPeriods.map((period, index) => (
            <div key={index} className="flex items-center gap-4">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium">{period.phase}</h4>
                  <Badge variant={
                    period.status === 'active' ? 'default' : 
                    period.status === 'upcoming' ? 'secondary' : 'outline'
                  }>
                    {period.status}
                  </Badge>
                </div>
                <p className="text-sm text-slate-600 dark:text-slate-400">{period.duration}</p>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold">{period.percentage}%</div>
                <div className="text-xs text-slate-600 dark:text-slate-400">locked</div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4">
          <h4 className="font-medium mb-2">Vesting Benefits</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Prevents token dumping</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Ensures long-term commitment</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Builds investor confidence</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Stable token price growth</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// Sample data for demonstration
export const sampleTokenData: TokenomicsData = {
  symbol: "SARAH",
  name: "Sarah Chen Token",
  currentPrice: 2.50,
  priceChange24h: 5.2,
  totalSupply: 10000,
  circulatingSupply: 8500,
  burnedSupply: 1500,
  marketCap: 25000,
  volume24h: 1250,
  holders: 45,
  transactions24h: 23
}

export const sampleUtilities = [
  {
    icon: <Target className="h-5 w-5" />,
    title: "Project Royalties",
    description: "Receive percentage of future project earnings",
    value: "5% royalty"
  },
  {
    icon: <Clock className="h-5 w-5" />,
    title: "Consultation Access",
    description: "Book 1-on-1 consultation sessions",
    value: "10 hours/1000 tokens"
  },
  {
    icon: <Award className="h-5 w-5" />,
    title: "Exclusive Content",
    description: "Access behind-the-scenes content and early releases",
    value: "Premium access"
  },
  {
    icon: <Handshake className="h-5 w-5" />,
    title: "Voting Rights",
    description: "Participate in project decision-making",
    value: "1 token = 1 vote"
  }
]

export const sampleDeflationData = {
  burnRate: 2,
  totalBurned: 1500,
  nextBurn: {
    amount: 500,
    condition: "10k Monthly Users Milestone",
    estimatedDate: "2024-03-31"
  }
}