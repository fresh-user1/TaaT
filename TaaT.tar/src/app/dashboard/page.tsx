"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Users, 
  Eye,
  MessageSquare,
  Calendar,
  Target,
  Clock,
  Plus,
  Edit,
  BarChart3,
  PieChart,
  Activity,
  Star,
  CheckCircle,
  AlertCircle,
  Award,
  FileText,
  Settings,
  Bell,
  ExternalLink
} from "lucide-react"

// Mock data for dashboard
const mockDashboardData = {
  talent: {
    name: "Sarah Chen",
    title: "Full-Stack Blockchain Developer",
    avatar: "/placeholder-avatar.jpg",
    tokenSymbol: "SARAH",
    tokenPrice: 2.50,
    tokenPriceChange: 5.2,
    totalRaised: 16250,
    monthlyVolume: 3750,
    investors: 45,
    holders: 45,
    rating: 4.9
  },
  
  tokenStats: {
    totalSupply: 10000,
    tokensSold: 6500,
    tokensAvailable: 3500,
    marketCap: 25000,
    dailyVolume: 1250,
    priceHistory: [
      { date: "2024-01", price: 2.00 },
      { date: "2024-02", price: 2.20 },
      { date: "2024-03", price: 2.35 },
      { date: "2024-04", price: 2.45 },
      { date: "2024-05", price: 2.50 },
      { date: "2024-06", price: 2.63 }
    ]
  },
  
  recentTransactions: [
    { id: "1", type: "PURCHASE", amount: 500, tokens: 200, investor: "0x1234...5678", date: "2024-06-15", status: "COMPLETED" },
    { id: "2", type: "PURCHASE", amount: 250, tokens: 100, investor: "0x8765...4321", date: "2024-06-14", status: "COMPLETED" },
    { id: "3", type: "TRANSFER", amount: 0, tokens: 50, from: "0x1111...2222", to: "0x3333...4444", date: "2024-06-13", status: "COMPLETED" },
    { id: "4", type: "PURCHASE", amount: 1000, tokens: 400, investor: "0x5555...6666", date: "2024-06-12", status: "PENDING" }
  ],
  
  projects: [
    { id: "1", title: "DeFi Lending Protocol", status: "COMPLETED", progress: 100, budget: 50000, spent: 48500, completionDate: "2023-06-15" },
    { id: "2", title: "NFT Marketplace", status: "IN_PROGRESS", progress: 75, budget: 75000, spent: 56250, startDate: "2023-08-01" },
    { id: "3", title: "DAO Governance Tool", status: "PLANNING", progress: 10, budget: 40000, spent: 0, plannedDate: "2024-07-01" }
  ],
  
  milestones: [
    { id: "1", title: "Smart Contract Audit", achieved: true, achievedAt: "2023-05-20", tokensBurned: 100 },
    { id: "2", title: "10k Monthly Users", achieved: false, targetDate: "2024-03-31", tokensToBurn: 200 },
    { id: "3", title: "Partnership with Major Exchange", achieved: false, targetDate: "2024-09-30", tokensToBurn: 500 }
  ],
  
  consultations: [
    { id: "1", client: "Crypto Startup Inc.", date: "2024-06-20", duration: 2, tokensUsed: 200, status: "SCHEDULED" },
    { id: "2", client: "DeFi Protocol Team", date: "2024-06-18", duration: 1, tokensUsed: 100, status: "COMPLETED" },
    { id: "3", client: "NFT Marketplace", date: "2024-06-15", duration: 3, tokensUsed: 300, status: "COMPLETED" }
  ],
  
  notifications: [
    { id: "1", type: "INVESTMENT", message: "New investment of $1,000 received", date: "2024-06-15", read: false },
    { id: "2", type: "MILESTONE", message: "Milestone 'Smart Contract Audit' achieved", date: "2024-06-14", read: true },
    { id: "3", type: "TRANSACTION", message: "Token transfer completed", date: "2024-06-13", read: true },
    { id: "4", type: "SYSTEM", message: "Monthly report is ready", date: "2024-06-12", read: false }
  ]
}

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("overview")
  const [newProject, setNewProject] = useState({ title: "", description: "", budget: "" })
  const [newMilestone, setNewMilestone] = useState({ title: "", description: "", targetDate: "", tokensToBurn: "" })

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('id-ID', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <Avatar className="h-16 w-16">
            <AvatarImage src={mockDashboardData.talent.avatar} alt={mockDashboardData.talent.name} />
            <AvatarFallback>{mockDashboardData.talent.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
          </Avatar>
          <div>
            <h1 className="text-3xl font-bold">{mockDashboardData.talent.name}</h1>
            <p className="text-slate-600 dark:text-slate-400">{mockDashboardData.talent.title}</p>
            <div className="flex items-center gap-4 mt-2">
              <Badge variant="outline" className="text-xs">
                {mockDashboardData.talent.tokenSymbol}
              </Badge>
              <div className="flex items-center gap-1">
                <Star className="h-4 w-4 text-yellow-500" />
                <span className="text-sm">{mockDashboardData.talent.rating}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button size="sm">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Token Price</p>
                <p className="text-2xl font-bold">${mockDashboardData.talent.tokenPrice}</p>
                <div className={`flex items-center gap-1 text-sm ${
                  mockDashboardData.talent.tokenPriceChange >= 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {mockDashboardData.talent.tokenPriceChange >= 0 ? (
                    <TrendingUp className="h-3 w-3" />
                  ) : (
                    <TrendingDown className="h-3 w-3" />
                  )}
                  {Math.abs(mockDashboardData.talent.tokenPriceChange)}%
                </div>
              </div>
              <DollarSign className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Total Raised</p>
                <p className="text-2xl font-bold">{formatCurrency(mockDashboardData.talent.totalRaised)}</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {formatCurrency(mockDashboardData.talent.monthlyVolume)} this month
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Investors</p>
                <p className="text-2xl font-bold">{mockDashboardData.talent.investors}</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {mockDashboardData.talent.holders} holders
                </p>
              </div>
              <Users className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 dark:text-slate-400">Tokens Sold</p>
                <p className="text-2xl font-bold">{mockDashboardData.tokenStats.tokensSold}</p>
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  {mockDashboardData.tokenStats.tokensAvailable} available
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="projects">Projects</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="activity">Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Recent Transactions */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Recent Transactions</CardTitle>
                <CardDescription>Latest token activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockDashboardData.recentTransactions.map(transaction => (
                    <div key={transaction.id} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          transaction.type === 'PURCHASE' ? 'bg-green-100' : 
                          transaction.type === 'TRANSFER' ? 'bg-blue-100' : 'bg-gray-100'
                        }`}>
                          {transaction.type === 'PURCHASE' && <DollarSign className="h-4 w-4 text-green-600" />}
                          {transaction.type === 'TRANSFER' && <Activity className="h-4 w-4 text-blue-600" />}
                        </div>
                        <div>
                          <p className="font-medium">
                            {transaction.type === 'PURCHASE' ? 'Purchase' : 'Transfer'}
                          </p>
                          <p className="text-sm text-slate-600 dark:text-slate-400">
                            {transaction.type === 'PURCHASE' ? transaction.investor : 
                             `${transaction.from} → ${transaction.to}`}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">
                          {transaction.amount > 0 ? formatCurrency(transaction.amount) : `${transaction.tokens} tokens`}
                        </p>
                        <p className="text-xs text-slate-600 dark:text-slate-400">
                          {formatDate(transaction.date)}
                        </p>
                        <Badge 
                          variant={transaction.status === 'COMPLETED' ? 'default' : 'secondary'} 
                          className="text-xs mt-1"
                        >
                          {transaction.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full justify-start" variant="outline">
                  <Plus className="h-4 w-4 mr-2" />
                  Create New Project
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <Target className="h-4 w-4 mr-2" />
                  Set New Milestone
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Schedule Consultation
                </Button>
                <Button className="w-full justify-start" variant="outline">
                  <FileText className="h-4 w-4 mr-2" />
                  Generate Report
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Upcoming Consultations */}
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Consultations</CardTitle>
              <CardDescription>Scheduled consultation sessions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockDashboardData.consultations.map(consultation => (
                  <div key={consultation.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium">{consultation.client}</p>
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          {formatDate(consultation.date)} • {consultation.duration} hours
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{consultation.tokensUsed} tokens</p>
                      <Badge 
                        variant={consultation.status === 'COMPLETED' ? 'default' : 'secondary'} 
                        className="text-xs"
                      >
                        {consultation.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Projects</h2>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Project
            </Button>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mockDashboardData.projects.map(project => (
              <Card key={project.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{project.title}</CardTitle>
                    <Badge variant={
                      project.status === 'COMPLETED' ? 'default' : 
                      project.status === 'IN_PROGRESS' ? 'secondary' : 'outline'
                    }>
                      {project.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Progress</span>
                      <span>{project.progress}%</span>
                    </div>
                    <Progress value={project.progress} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-600 dark:text-slate-400">Budget</span>
                      <p className="font-medium">{formatCurrency(project.budget)}</p>
                    </div>
                    <div>
                      <span className="text-slate-600 dark:text-slate-400">Spent</span>
                      <p className="font-medium">{formatCurrency(project.spent)}</p>
                    </div>
                  </div>
                  
                  {project.completionDate && (
                    <p className="text-xs text-green-600">
                      Completed: {formatDate(project.completionDate)}
                    </p>
                  )}
                  
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      <Eye className="h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Token Performance</CardTitle>
                <CardDescription>Price trends over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockDashboardData.tokenStats.priceHistory.map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm">{item.date}</span>
                      <span className="font-medium">${item.price}</span>
                      {index > 0 && (
                        <div className={`flex items-center gap-1 text-xs ${
                          item.price > mockDashboardData.tokenStats.priceHistory[index - 1].price 
                            ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {item.price > mockDashboardData.tokenStats.priceHistory[index - 1].price ? (
                            <TrendingUp className="h-3 w-3" />
                          ) : (
                            <TrendingDown className="h-3 w-3" />
                          )}
                          {Math.abs(((item.price - mockDashboardData.tokenStats.priceHistory[index - 1].price) / 
                            mockDashboardData.tokenStats.priceHistory[index - 1].price * 100)).toFixed(1)}%
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Milestone Progress</CardTitle>
                <CardDescription>Track your achievements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockDashboardData.milestones.map(milestone => (
                    <div key={milestone.id} className="flex items-start gap-3">
                      <div className={`w-4 h-4 rounded-full mt-0.5 flex-shrink-0 ${
                        milestone.achieved ? 'bg-green-600' : 'bg-slate-300'
                      }`} />
                      <div className="flex-1">
                        <h4 className="font-medium">{milestone.title}</h4>
                        <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
                          {milestone.description}
                        </p>
                        {milestone.achieved && milestone.achievedAt && (
                          <div className="flex items-center gap-2 text-xs text-green-600">
                            <CheckCircle className="h-3 w-3" />
                            Achieved on {formatDate(milestone.achievedAt)}
                            {milestone.tokensBurned && (
                              <Badge variant="outline" className="text-xs">
                                {milestone.tokensBurned} tokens burned
                              </Badge>
                            )}
                          </div>
                        )}
                        {!milestone.achieved && milestone.targetDate && (
                          <div className="flex items-center gap-2 text-xs text-slate-500">
                            <AlertCircle className="h-3 w-3" />
                            Target: {formatDate(milestone.targetDate)}
                            {milestone.tokensToBurn && (
                              <Badge variant="outline" className="text-xs">
                                {milestone.tokensToBurn} tokens to burn
                              </Badge>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Stay updated with your activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockDashboardData.notifications.map(notification => (
                  <div key={notification.id} className={`flex items-start gap-3 p-3 rounded-lg ${
                    notification.read ? 'bg-slate-50 dark:bg-slate-800' : 'bg-blue-50 dark:bg-blue-900/20'
                  }`}>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                      notification.type === 'INVESTMENT' ? 'bg-green-100' :
                      notification.type === 'MILESTONE' ? 'bg-yellow-100' :
                      notification.type === 'TRANSACTION' ? 'bg-blue-100' : 'bg-gray-100'
                    }`}>
                      {notification.type === 'INVESTMENT' && <DollarSign className="h-4 w-4 text-green-600" />}
                      {notification.type === 'MILESTONE' && <Award className="h-4 w-4 text-yellow-600" />}
                      {notification.type === 'TRANSACTION' && <Activity className="h-4 w-4 text-blue-600" />}
                      {notification.type === 'SYSTEM' && <Bell className="h-4 w-4 text-gray-600" />}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{notification.message}</p>
                      <p className="text-xs text-slate-600 dark:text-slate-400">
                        {formatDate(notification.date)}
                      </p>
                    </div>
                    {!notification.read && (
                      <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-2" />
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}