import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Header } from "@/components/header";
import { ThemeProvider } from "next-themes";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Talent-as-a-Token (TaaT) - Platform Web3 Talent",
  description: "Platform revolusioner yang mengubah talenta menjadi aset digital. Investasi dalam potensi manusia, bangun ekonomi kreatif terdesentralisasi.",
  keywords: ["TaaT", "Talent-as-a-Token", "Web3", "Blockchain", "Talent", "Investment", "Crypto", "DeFi"],
  authors: [{ name: "TaaT Team" }],
  openGraph: {
    title: "Talent-as-a-Token (TaaT)",
    description: "Platform revolusioner yang mengubah talenta menjadi aset digital",
    url: "https://taat.example.com",
    siteName: "TaaT",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Talent-as-a-Token (TaaT)",
    description: "Platform revolusioner yang mengubah talenta menjadi aset digital",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <Header />
          <main>{children}</main>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
