"use client"

import { useState } from "react"
import { useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { 
  ArrowUpRight, 
  ArrowDownRight, 
  Users, 
  DollarSign, 
  TrendingUp, 
  Clock,
  Target,
  CheckCircle,
  Star,
  Heart,
  Share2,
  Globe,
  Twitter,
  Github,
  Linkedin,
  Calendar,
  BarChart3,
  PieChart,
  Activity,
  Award,
  BookOpen,
  MessageSquare
} from "lucide-react"

// Mock data for talent profile
const mockTalent = {
  id: "1",
  name: "Sarah Chen",
  title: "Full-Stack Blockchain Developer",
  bio: "Passionate blockchain developer with 5+ years of experience building decentralized applications. Specialized in smart contract development, DeFi protocols, and Web3 infrastructure. Committed to creating innovative solutions that drive adoption of blockchain technology.",
  avatar: "/placeholder-avatar.jpg",
  skills: ["Solidity", "React", "Node.js", "Web3", "TypeScript", "Ethereum", "IPFS", "GraphQL"],
  experience: 5,
  website: "https://sarahchen.dev",
  twitter: "@sarahchen_dev",
  github: "sarahchen",
  linkedin: "sarahchen",
  isVerified: true,
  location: "San Francisco, CA",
  joinedDate: "2023-01-15",
  
  // Token information
  tokenSymbol: "SARAH",
  tokenName: "Sarah Chen Token",
  tokenPrice: 2.50,
  tokenPriceChange: 5.2, // percentage
  tokenSupply: 10000,
  tokensSold: 6500,
  tokensAvailable: 3500,
  minInvestment: 100,
  maxInvestment: 5000,
  royaltyPercentage: 5,
  consultationHours: 10,
  vestingPeriod: 36, // months
  status: "ACTIVE",
  
  // Financial data
  totalRaised: 16250,
  marketCap: 25000,
  dailyVolume: 1250,
  investors: 45,
  holders: 45,
  
  // Projects
  projects: [
    {
      id: "1",
      title: "DeFi Lending Protocol",
      description: "Built a decentralized lending protocol with $2M+ TVL",
      status: "COMPLETED",
      completedDate: "2023-06-15",
      budget: 50000
    },
    {
      id: "2", 
      title: "NFT Marketplace",
      description: "Developed a full-featured NFT marketplace with gas optimization",
      status: "IN_PROGRESS",
      startDate: "2023-08-01",
      budget: 75000
    }
  ],
  
  // Milestones
  milestones: [
    {
      id: "1",
      title: "Smart Contract Audit",
      description: "Completed audit for DeFi protocol",
      achieved: true,
      achievedAt: "2023-05-20"
    },
    {
      id: "2",
      title: "10k Monthly Users",
      description: "Reach 10,000 monthly active users",
      achieved: false,
      targetDate: "2024-03-31"
    }
  ],
  
  // Token holders
  topHolders: [
    { address: "0x1234...5678", amount: 1500, percentage: 15 },
    { address: "0x8765...4321", amount: 1200, percentage: 12 },
    { address: "0x2468...1357", amount: 1000, percentage: 10 },
    { address: "0x9753...8642", amount: 800, percentage: 8 },
    { address: "0x1122...3344", amount: 500, percentage: 5 }
  ],
  
  // Price history (mock data for chart)
  priceHistory: [
    { date: "2024-01", price: 2.00 },
    { date: "2024-02", price: 2.20 },
    { date: "2024-03", price: 2.35 },
    { date: "2024-04", price: 2.45 },
    { date: "2024-05", price: 2.50 },
    { date: "2024-06", price: 2.63 }
  ]
}

export default function TalentProfilePage() {
  const params = useParams()
  const [investmentAmount, setInvestmentAmount] = useState(100)
  
  const tokensToReceive = Math.floor(investmentAmount / mockTalent.tokenPrice)
  const progressPercentage = (mockTalent.tokensSold / mockTalent.tokenSupply) * 100

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header Section */}
      <div className="grid lg:grid-cols-3 gap-8 mb-8">
        {/* Profile Info */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-start gap-4">
            <Avatar className="h-20 w-20">
              <AvatarImage src={mockTalent.avatar} alt={mockTalent.name} />
              <AvatarFallback className="text-xl">{mockTalent.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-2">
                <h1 className="text-3xl font-bold">{mockTalent.name}</h1>
                {mockTalent.isVerified && (
                  <CheckCircle className="h-6 w-6 text-blue-600" />
                )}
              </div>
              <p className="text-xl text-slate-600 dark:text-slate-400 mb-3">{mockTalent.title}</p>
              <p className="text-slate-600 dark:text-slate-400 mb-4">{mockTalent.bio}</p>
              
              {/* Social Links */}
              <div className="flex items-center gap-4 mb-4">
                {mockTalent.website && (
                  <a href={mockTalent.website} className="text-slate-600 hover:text-primary">
                    <Globe className="h-5 w-5" />
                  </a>
                )}
                {mockTalent.twitter && (
                  <a href={`https://twitter.com/${mockTalent.twitter}`} className="text-slate-600 hover:text-primary">
                    <Twitter className="h-5 w-5" />
                  </a>
                )}
                {mockTalent.github && (
                  <a href={`https://github.com/${mockTalent.github}`} className="text-slate-600 hover:text-primary">
                    <Github className="h-5 w-5" />
                  </a>
                )}
                {mockTalent.linkedin && (
                  <a href={`https://linkedin.com/in/${mockTalent.linkedin}`} className="text-slate-600 hover:text-primary">
                    <Linkedin className="h-5 w-5" />
                  </a>
                )}
              </div>
              
              {/* Stats */}
              <div className="flex items-center gap-6 text-sm text-slate-600 dark:text-slate-400">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  Bergabung Jan 2023
                </div>
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4" />
                  {mockTalent.experience} tahun pengalaman
                </div>
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4" />
                  4.9 rating
                </div>
              </div>
            </div>
          </div>
          
          {/* Skills */}
          <div>
            <h3 className="text-lg font-semibold mb-3">Keahlian</h3>
            <div className="flex flex-wrap gap-2">
              {mockTalent.skills.map(skill => (
                <Badge key={skill} variant="secondary">{skill}</Badge>
              ))}
            </div>
          </div>
        </div>
        
        {/* Token Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl">{mockTalent.tokenSymbol}</CardTitle>
                <CardDescription>{mockTalent.tokenName}</CardDescription>
              </div>
              <Badge variant={mockTalent.status === "ACTIVE" ? "default" : "secondary"}>
                {mockTalent.status}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-3xl font-bold">${mockTalent.tokenPrice}</span>
              <div className={`flex items-center gap-1 ${mockTalent.tokenPriceChange >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {mockTalent.tokenPriceChange >= 0 ? (
                  <ArrowUpRight className="h-4 w-4" />
                ) : (
                  <ArrowDownRight className="h-4 w-4" />
                )}
                <span className="font-medium">{Math.abs(mockTalent.tokenPriceChange)}%</span>
              </div>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Token Terjual</span>
                <span>{mockTalent.tokensSold}/{mockTalent.tokenSupply}</span>
              </div>
              <Progress value={progressPercentage} className="h-2" />
              <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400">
                <span>{progressPercentage.toFixed(1)}% terjual</span>
                <span>${mockTalent.totalRaised.toLocaleString()} terkumpul</span>
              </div>
            </div>
            
            <Separator />
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-600 dark:text-slate-400">Market Cap</span>
                <p className="font-semibold">${mockTalent.marketCap.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-slate-600 dark:text-slate-400">24h Volume</span>
                <p className="font-semibold">${mockTalent.dailyVolume.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-slate-600 dark:text-slate-400">Investors</span>
                <p className="font-semibold">{mockTalent.investors}</p>
              </div>
              <div>
                <span className="text-slate-600 dark:text-slate-400">Holders</span>
                <p className="font-semibold">{mockTalent.holders}</p>
              </div>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Target className="h-4 w-4" />
                <span>{mockTalent.royaltyPercentage}% royalti proyek</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Clock className="h-4 w-4" />
                <span>{mockTalent.consultationHours} jam konsultasi/1000 token</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Activity className="h-4 w-4" />
                <span>Vesting {mockTalent.vestingPeriod} bulan</span>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Button className="flex-1">
                Investasi Sekarang
              </Button>
              <Button variant="outline" size="icon">
                <Heart className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon">
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Tabs Section */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="projects">Proyek</TabsTrigger>
          <TabsTrigger value="tokenomics">Tokenomics</TabsTrigger>
          <TabsTrigger value="holders">Holders</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Investment Calculator */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-5 w-5" />
                  Kalkulator Investasi
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Jumlah Investasi (USD)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min={mockTalent.minInvestment}
                      max={mockTalent.maxInvestment}
                      value={investmentAmount}
                      onChange={(e) => setInvestmentAmount(Number(e.target.value))}
                      className="flex-1"
                    />
                    <span className="font-medium min-w-16">${investmentAmount}</span>
                  </div>
                  <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400 mt-1">
                    <span>${mockTalent.minInvestment}</span>
                    <span>${mockTalent.maxInvestment}</span>
                  </div>
                </div>
                
                <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm">Token yang diterima</span>
                    <span className="text-lg font-bold">{tokensToReceive} {mockTalent.tokenSymbol}</span>
                  </div>
                  <div className="flex justify-between items-center text-sm text-slate-600 dark:text-slate-400">
                    <span>Harga per token</span>
                    <span>${mockTalent.tokenPrice}</span>
                  </div>
                </div>
                
                <Button className="w-full">
                  Investasi ${investmentAmount}
                </Button>
              </CardContent>
            </Card>
            
            {/* Milestones */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Pencapaian
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockTalent.milestones.map(milestone => (
                  <div key={milestone.id} className="flex items-start gap-3">
                    <div className={`w-4 h-4 rounded-full mt-0.5 flex-shrink-0 ${
                      milestone.achieved ? 'bg-green-600' : 'bg-slate-300'
                    }`} />
                    <div className="flex-1">
                      <h4 className="font-medium">{milestone.title}</h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {milestone.description}
                      </p>
                      {milestone.achieved && milestone.achievedAt && (
                        <p className="text-xs text-green-600 mt-1">
                          Dicapai pada {new Date(milestone.achievedAt).toLocaleDateString('id-ID')}
                        </p>
                      )}
                      {!milestone.achieved && milestone.targetDate && (
                        <p className="text-xs text-slate-500 mt-1">
                          Target: {new Date(milestone.targetDate).toLocaleDateString('id-ID')}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="projects" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {mockTalent.projects.map(project => (
              <Card key={project.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{project.title}</CardTitle>
                    <Badge variant={
                      project.status === 'COMPLETED' ? 'default' : 
                      project.status === 'IN_PROGRESS' ? 'secondary' : 'outline'
                    }>
                      {project.status === 'COMPLETED' ? 'Selesai' : 
                       project.status === 'IN_PROGRESS' ? 'Dalam Proses' : 'Perencanaan'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {project.description}
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-600 dark:text-slate-400">Anggaran</span>
                      <p className="font-medium">${project.budget?.toLocaleString()}</p>
                    </div>
                    <div>
                      <span className="text-slate-600 dark:text-slate-400">Status</span>
                      <p className="font-medium">
                        {project.status === 'COMPLETED' ? 'Selesai' : 
                         project.status === 'IN_PROGRESS' ? 'Dalam Proses' : 'Perencanaan'}
                      </p>
                    </div>
                  </div>
                  
                  {project.completedDate && (
                    <div className="text-xs text-green-600">
                      Selesai pada {new Date(project.completedDate).toLocaleDateString('id-ID')}
                    </div>
                  )}
                  
                  {project.startDate && project.status === 'IN_PROGRESS' && (
                    <div className="text-xs text-blue-600">
                      Dimulai pada {new Date(project.startDate).toLocaleDateString('id-ID')}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="tokenomics" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  Distribusi Token
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Publik (65%)</span>
                    <span className="font-medium">6,500 tokens</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Tim (20%)</span>
                    <span className="font-medium">2,000 tokens</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Reserve (10%)</span>
                    <span className="font-medium">1,000 tokens</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Advisors (5%)</span>
                    <span className="font-medium">500 tokens</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Utilitas Token
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium">Akses Konsultasi</h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {mockTalent.consultationHours} jam konsultasi per 1000 token
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium">Royalti Proyek</h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {mockTalent.royaltyPercentage}% dari pendapatan proyek pribadi
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium">Hak Suara</h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        Voting rights untuk pengambilan keputusan proyek
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                    <div>
                      <h4 className="font-medium">Konten Eksklusif</h4>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        Akses ke behind-the-scenes dan proyek rahasia
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="holders" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Top Token Holders
              </CardTitle>
              <CardDescription>
                Daftar pemegang token terbesar
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {mockTalent.topHolders.map((holder, index) => (
                  <div key={holder.address} className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-bold text-primary">{index + 1}</span>
                      </div>
                      <div>
                        <p className="font-medium">{holder.address}</p>
                        <p className="text-sm text-slate-600 dark:text-slate-400">
                          {holder.percentage}% dari total supply
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{holder.amount.toLocaleString()} tokens</p>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        ${(holder.amount * mockTalent.tokenPrice).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}