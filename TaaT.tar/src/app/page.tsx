import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Users, TrendingUp, Shield, Zap, Coins, Handshake } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="container mx-auto px-4 py-24 sm:py-32">
          <div className="text-center">
            <Badge variant="secondary" className="mb-4">
              Web3 Talent Platform
            </Badge>
            <h1 className="text-4xl sm:text-6xl font-bold tracking-tight text-slate-900 dark:text-slate-100 mb-6">
              Talent-as-a-Token
              <span className="block text-primary">(TaaT)</span>
            </h1>
            <p className="text-xl text-slate-600 dark:text-slate-400 max-w-3xl mx-auto mb-8">
              Platform revolusioner yang mengubah talenta menjadi aset digital. 
              Investasi dalam potensi manusia, bangun ekonomi kreatif terdesentralisasi.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8">
                Jelajahi Talenta
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8">
                Menjadi Talenta
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-16 bg-white dark:bg-slate-800">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Visi Kami
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Membangun ekonomi kreatif yang terdesentralisasi, di mana talenta adalah aset investasi 
              dan individu memiliki kendali penuh atas karir mereka.
            </p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Pemberdayaan Talenta</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Individu mengontrol karir mereka, membiayai proyek impian, dan berinteraksi langsung dengan audiens.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Investasi Cerdas</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Investor mendapatkan akses ke talenta kelas dunia dengan model pendapatan baru yang transparan.
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Transparansi Penuh</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Semua data tercatat di blockchain, menciptakan tingkat kepercayaan yang belum pernah ada sebelumnya.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Bagaimana TaaT Bekerja?
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400">
              Platform sederhana yang menghubungkan talenta dengan investor
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* For Talents */}
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-sm font-bold">1</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Buat Profil Token</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Talenta membuat "profil token" dengan personal whitepaper, tokenomics, 
                    dan hak & kewajiban untuk pemegang token.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-sm font-bold">2</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Luncurkan ITO</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Initial Talent Offering - jual token kepada publik untuk menggalang dana 
                    proyek dan pengembangan karir.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-sm font-bold">3</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Penuhi Komitmen</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Kerjakan proyek dan berkontribusi sesuai janji di smart contract 
                    untuk meningkatkan nilai token.
                  </p>
                </div>
              </div>
            </div>

            {/* For Investors */}
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-sm font-bold">1</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Cari Talenta</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Telusuri marketplace berdasarkan keahlian, proyek, dan reputasi on-chain 
                    untuk menemukan talenta potensial.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-sm font-bold">2</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Beli Token</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Investasi dalam talenta yang Anda yakini memiliki potensi besar untuk 
                    pertumbuhan karir dan proyek.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-8 h-8 bg-secondary rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <span className="text-white text-sm font-bold">3</span>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">Tukar Token untuk Jasa</h3>
                  <p className="text-slate-600 dark:text-slate-400">
                    Gunakan token untuk mendapatkan jam kerja, konsultasi, atau hak eksklusif 
                  sesuai ketentuan.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Token Mechanics Section */}
      <section className="py-16 bg-white dark:bg-slate-800">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 dark:text-slate-100 mb-4">
              Mekanisme Token yang Cerdas
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400">
              Sistem dirancang untuk menjaga dan meningkatkan nilai token
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center mb-4">
                  <Zap className="h-6 w-6 text-green-600 dark:text-green-400" />
                </div>
                <CardTitle>Utility Nyata</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-slate-600 dark:text-slate-400">
                  <li>• Tukar token untuk jam kerja</li>
                  <li>• Akses konsultasi eksklusif</li>
                  <li>• Hak suara dalam proyek</li>
                  <li>• Konten behind-the-scenes</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center mb-4">
                  <Coins className="h-6 w-6 text-orange-600 dark:text-orange-400" />
                </div>
                <CardTitle>Mekanisme Deflasi</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-slate-600 dark:text-slate-400">
                  <li>• Pembakaran fee transaksi</li>
                  <li>• Pembakaran token saat milestone</li>
                  <li>• Pengurangan suplai permanen</li>
                  <li>• Peningkatan nilai otomatis</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center mb-4">
                  <Handshake className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                </div>
                <CardTitle>Sistem Vesting</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-slate-600 dark:text-slate-400">
                  <li>• Kunci token talenta 3-5 tahun</li>
                  <li>• Pelepasan bertahap</li>
                  <li>• Mencegah dumping</li>
                  <li>• Komitmen jangka panjang</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Bergabunglah dengan Revolusi Talenta Web3
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Jadilah bagian dari ekonomi kreatif terdesentralisasi pertama di dunia
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" className="text-lg px-8">
              Mulai sebagai Talenta
            </Button>
            <Button size="lg" variant="outline" className="text-lg px-8 border-white text-white hover:bg-white hover:text-primary">
              Mulai sebagai Investor
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}