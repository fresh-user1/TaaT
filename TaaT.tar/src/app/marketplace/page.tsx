"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Search, 
  Filter, 
  TrendingUp, 
  Users, 
  Star, 
  DollarSign,
  Clock,
  Target,
  CheckCircle,
  ArrowUpRight,
  Heart,
  Share2
} from "lucide-react"

// Mock data for talents
const mockTalents = [
  {
    id: "1",
    name: "Sarah Chen",
    title: "Full-Stack Blockchain Developer",
    avatar: "/placeholder-avatar.jpg",
    skills: ["Solidity", "React", "Node.js", "Web3"],
    experience: 5,
    tokenSymbol: "SARAH",
    tokenPrice: 2.50,
    tokenSupply: 10000,
    tokensSold: 6500,
    minInvestment: 100,
    maxInvestment: 5000,
    royaltyPercentage: 5,
    consultationHours: 10,
    isVerified: true,
    totalRaised: 16250,
    investors: 45,
    status: "ACTIVE",
    description: "Developer spesialis smart contract dan dApps dengan pengalaman 5+ tahun di industri Web3."
  },
  {
    id: "2",
    name: "Marcus Rodriguez",
    title: "Digital Artist & NFT Creator",
    avatar: "/placeholder-avatar.jpg",
    skills: ["Digital Art", "NFT", "3D Modeling", "Animation"],
    experience: 7,
    tokenSymbol: "MARCUS",
    tokenPrice: 1.80,
    tokenSupply: 15000,
    tokensSold: 8900,
    minInvestment: 50,
    maxInvestment: 3000,
    royaltyPercentage: 8,
    consultationHours: 5,
    isVerified: true,
    totalRaised: 16020,
    investors: 67,
    status: "ACTIVE",
    description: "Seniman digital yang telah menciptakan berbagai koleksi NFT sukses dengan total volume trading $2M+."
  },
  {
    id: "3",
    name: "Dr. Emily Watson",
    title: "AI & Machine Learning Expert",
    avatar: "/placeholder-avatar.jpg",
    skills: ["Python", "TensorFlow", "PyTorch", "Data Science"],
    experience: 8,
    tokenSymbol: "EMILY",
    tokenPrice: 5.00,
    tokenSupply: 5000,
    tokensSold: 3200,
    minInvestment: 250,
    maxInvestment: 10000,
    royaltyPercentage: 3,
    consultationHours: 15,
    isVerified: true,
    totalRaised: 16000,
    investors: 28,
    status: "ACTIVE",
    description: "PhD dalam Machine Learning dengan fokus pada AI ethics dan aplikasi industri."
  },
  {
    id: "4",
    name: "Alex Kumar",
    title: "DeFi Protocol Developer",
    avatar: "/placeholder-avatar.jpg",
    skills: ["DeFi", "Rust", "Smart Contracts", "Yield Farming"],
    experience: 4,
    tokenSymbol: "ALEX",
    tokenPrice: 3.20,
    tokenSupply: 8000,
    tokensSold: 4800,
    minInvestment: 150,
    maxInvestment: 4000,
    royaltyPercentage: 6,
    consultationHours: 8,
    isVerified: false,
    totalRaised: 15360,
    investors: 32,
    status: "PENDING",
    description: "Spesialis pengembangan protokol DeFi dengan fokus pada yield optimization dan risk management."
  }
]

const skillOptions = [
  "Solidity", "React", "Node.js", "Web3", "Digital Art", "NFT", 
  "3D Modeling", "Python", "TensorFlow", "PyTorch", "DeFi", "Rust"
]

const statusOptions = [
  { value: "all", label: "Semua Status" },
  { value: "active", label: "Aktif" },
  { value: "pending", label: "Pending" }
]

export default function MarketplacePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSkill, setSelectedSkill] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [sortBy, setSortBy] = useState("popular")

  const filteredTalents = mockTalents.filter(talent => {
    const matchesSearch = talent.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         talent.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         talent.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()))
    
    const matchesSkill = selectedSkill === "all" || talent.skills.includes(selectedSkill)
    const matchesStatus = selectedStatus === "all" || 
                         (selectedStatus === "active" && talent.status === "ACTIVE") ||
                         (selectedStatus === "pending" && talent.status === "PENDING")
    
    return matchesSearch && matchesSkill && matchesStatus
  })

  const sortedTalents = [...filteredTalents].sort((a, b) => {
    switch (sortBy) {
      case "popular":
        return b.investors - a.investors
      case "price_low":
        return a.tokenPrice - b.tokenPrice
      case "price_high":
        return b.tokenPrice - a.tokenPrice
      case "raised":
        return b.totalRaised - a.totalRaised
      default:
        return 0
    }
  })

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Marketplace Talenta</h1>
        <p className="text-slate-600 dark:text-slate-400">
          Temukan dan investasi dalam talenta Web3 terbaik
        </p>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-slate-800 rounded-lg p-6 mb-8">
        <div className="grid md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Cari talenta..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <Select value={selectedSkill} onValueChange={setSelectedSkill}>
            <SelectTrigger>
              <SelectValue placeholder="Pilih Keahlian" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Semua Keahlian</SelectItem>
              {skillOptions.map(skill => (
                <SelectItem key={skill} value={skill}>{skill}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger>
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {statusOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger>
              <SelectValue placeholder="Urutkan" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="popular">Terpopuler</SelectItem>
              <SelectItem value="price_low">Harga Terendah</SelectItem>
              <SelectItem value="price_high">Harga Tertinggi</SelectItem>
              <SelectItem value="raised">Terkumpul Terbanyak</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-blue-600" />
              <span className="text-sm text-slate-600 dark:text-slate-400">Total Talenta</span>
            </div>
            <p className="text-2xl font-bold">{mockTalents.length}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <span className="text-sm text-slate-600 dark:text-slate-400">Total Terkumpul</span>
            </div>
            <p className="text-2xl font-bold">${(mockTalents.reduce((sum, t) => sum + t.totalRaised, 0) / 1000).toFixed(0)}K</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4 text-yellow-600" />
              <span className="text-sm text-slate-600 dark:text-slate-400">Total Investor</span>
            </div>
            <p className="text-2xl font-bold">{mockTalents.reduce((sum, t) => sum + t.investors, 0)}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span className="text-sm text-slate-600 dark:text-slate-400">Terverifikasi</span>
            </div>
            <p className="text-2xl font-bold">{mockTalents.filter(t => t.isVerified).length}</p>
          </CardContent>
        </Card>
      </div>

      {/* Talent Cards */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedTalents.map((talent) => (
          <Card key={talent.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={talent.avatar} alt={talent.name} />
                    <AvatarFallback>{talent.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">{talent.name}</CardTitle>
                      {talent.isVerified && (
                        <CheckCircle className="h-4 w-4 text-blue-600" />
                      )}
                    </div>
                    <CardDescription className="text-sm">{talent.title}</CardDescription>
                  </div>
                </div>
                <Badge variant={talent.status === "ACTIVE" ? "default" : "secondary"}>
                  {talent.status}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <p className="text-sm text-slate-600 dark:text-slate-400 line-clamp-2">
                {talent.description}
              </p>
              
              {/* Skills */}
              <div className="flex flex-wrap gap-1">
                {talent.skills.slice(0, 3).map(skill => (
                  <Badge key={skill} variant="outline" className="text-xs">
                    {skill}
                  </Badge>
                ))}
                {talent.skills.length > 3 && (
                  <Badge variant="outline" className="text-xs">
                    +{talent.skills.length - 3}
                  </Badge>
                )}
              </div>
              
              {/* Token Info */}
              <div className="bg-slate-50 dark:bg-slate-800 rounded-lg p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{talent.tokenSymbol}</span>
                  <span className="text-lg font-bold">${talent.tokenPrice}</span>
                </div>
                
                <div className="space-y-1">
                  <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400">
                    <span>Terjual: {talent.tokensSold}/{talent.tokenSupply}</span>
                    <span>{((talent.tokensSold / talent.tokenSupply) * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={(talent.tokensSold / talent.tokenSupply) * 100} className="h-2" />
                </div>
                
                <div className="flex justify-between text-xs text-slate-600 dark:text-slate-400">
                  <span className="flex items-center gap-1">
                    <DollarSign className="h-3 w-3" />
                    ${talent.totalRaised.toLocaleString()}
                  </span>
                  <span className="flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    {talent.investors} investor
                  </span>
                </div>
              </div>
              
              {/* Token Benefits */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                  <Target className="h-3 w-3" />
                  {talent.royaltyPercentage}% royalti
                </div>
                <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400">
                  <Clock className="h-3 w-3" />
                  {talent.consultationHours} jam/1000 token
                </div>
              </div>
              
              {/* Actions */}
              <div className="flex gap-2">
                <Button className="flex-1" size="sm">
                  Investasi Sekarang
                </Button>
                <Button variant="outline" size="sm">
                  <ArrowUpRight className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {sortedTalents.length === 0 && (
        <div className="text-center py-12">
          <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Tidak ada talenta ditemukan</h3>
          <p className="text-slate-600 dark:text-slate-400">
            Coba调整 pencarian atau filter Anda
          </p>
        </div>
      )}
    </div>
  )
}