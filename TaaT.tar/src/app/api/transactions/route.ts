import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '20')
    const tokenId = searchParams.get('tokenId')
    const userId = searchParams.get('userId')
    const type = searchParams.get('type') || ''
    const status = searchParams.get('status') || ''

    const skip = (page - 1) * limit

    // Build where clause
    let where: any = {}
    if (tokenId) where.tokenId = tokenId
    if (userId) {
      where.OR = [
        { fromUserId: userId },
        { toUserId: userId }
      ]
    }
    if (type && type !== 'all') where.type = type.toUpperCase()
    if (status && status !== 'all') where.status = status.toUpperCase()

    const transactions = await db.transaction.findMany({
      where,
      include: {
        token: {
          select: {
            id: true,
            symbol: true,
            name: true
          }
        },
        from: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        to: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' }
    })

    const total = await db.transaction.count({ where })

    // Transform data
    const transformedTransactions = transactions.map(transaction => ({
      id: transaction.id,
      amount: transaction.amount,
      price: transaction.price,
      type: transaction.type,
      status: transaction.status,
      fee: transaction.fee,
      createdAt: transaction.createdAt,
      token: {
        id: transaction.token.id,
        symbol: transaction.token.symbol,
        name: transaction.token.name
      },
      fromUser: transaction.from ? {
        id: transaction.from.id,
        name: transaction.from.name,
        avatar: transaction.from.avatar
      } : null,
      toUser: transaction.to ? {
        id: transaction.to.id,
        name: transaction.to.name,
        avatar: transaction.to.avatar
      } : null
    }))

    return NextResponse.json({
      success: true,
      data: transformedTransactions,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })

  } catch (error) {
    console.error('Error fetching transactions:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      tokenId,
      fromUserId,
      toUserId,
      amount,
      type,
      price
    } = body

    // Validate required fields
    if (!tokenId || !amount || !type || !price) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Get token details
    const token = await db.token.findUnique({
      where: { id: tokenId }
    })

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'Token not found' },
        { status: 404 }
      )
    }

    // Validate transaction type
    const validTypes = ['PURCHASE', 'SALE', 'TRANSFER', 'BURN', 'REWARD']
    if (!validTypes.includes(type.toUpperCase())) {
      return NextResponse.json(
        { success: false, error: 'Invalid transaction type' },
        { status: 400 }
      )
    }

    // Calculate transaction fee (2% for most transactions, 0% for burns and rewards)
    const fee = type === 'BURN' || type === 'REWARD' ? 0 : (amount * price * 0.02)

    // Create transaction
    const transaction = await db.transaction.create({
      data: {
        tokenId,
        fromUserId,
        toUserId,
        amount: parseInt(amount),
        price: parseFloat(price),
        type: type.toUpperCase(),
        status: 'PENDING',
        fee
      },
      include: {
        token: {
          select: {
            id: true,
            symbol: true,
            name: true
          }
        },
        from: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        to: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    })

    // Process transaction based on type
    switch (type.toUpperCase()) {
      case 'TRANSFER':
        if (!fromUserId || !toUserId) {
          return NextResponse.json(
            { success: false, error: 'From and to user required for transfer' },
            { status: 400 }
          )
        }

        // Check if sender has enough tokens
        const senderHolder = await db.tokenHolder.findUnique({
          where: {
            tokenId_userId: {
              tokenId,
              userId: fromUserId
            }
          }
        })

        if (!senderHolder || senderHolder.amount < amount) {
          return NextResponse.json(
            { success: false, error: 'Insufficient token balance' },
            { status: 400 }
          )
        }

        // Update token holders
        await db.tokenHolder.update({
          where: {
            tokenId_userId: {
              tokenId,
              userId: fromUserId
            }
          },
          data: {
            amount: {
              decrement: parseInt(amount)
            }
          }
        })

        await db.tokenHolder.upsert({
          where: {
            tokenId_userId: {
              tokenId,
              userId: toUserId
            }
          },
          update: {
            amount: {
              increment: parseInt(amount)
            }
          },
          create: {
            tokenId,
            userId: toUserId,
            amount: parseInt(amount),
            locked: 0
          }
        })

        // Update transaction status to completed
        await db.transaction.update({
          where: { id: transaction.id },
          data: { status: 'COMPLETED' }
        })
        break

      case 'BURN':
        if (!fromUserId) {
          return NextResponse.json(
            { success: false, error: 'From user required for burn' },
            { status: 400 }
          )
        }

        // Check if user has enough tokens
        const burnerHolder = await db.tokenHolder.findUnique({
          where: {
            tokenId_userId: {
              tokenId,
              userId: fromUserId
            }
          }
        })

        if (!burnerHolder || burnerHolder.amount < amount) {
          return NextResponse.json(
            { success: false, error: 'Insufficient token balance' },
            { status: 400 }
          )
        }

        // Burn tokens (remove from holder)
        await db.tokenHolder.update({
          where: {
            tokenId_userId: {
              tokenId,
              userId: fromUserId
            }
          },
          data: {
            amount: {
              decrement: parseInt(amount)
            }
          }
        })

        // Update token total supply (conceptual - in real blockchain this would be different)
        // For now, we'll just mark the transaction as completed
        await db.transaction.update({
          where: { id: transaction.id },
          data: { status: 'COMPLETED' }
        })
        break

      case 'REWARD':
        if (!toUserId) {
          return NextResponse.json(
            { success: false, error: 'To user required for reward' },
            { status: 400 }
          )
        }

        // Add tokens to recipient
        await db.tokenHolder.upsert({
          where: {
            tokenId_userId: {
              tokenId,
              userId: toUserId
            }
          },
          update: {
            amount: {
              increment: parseInt(amount)
            }
          },
          create: {
            tokenId,
            userId: toUserId,
            amount: parseInt(amount),
            locked: 0
          }
        })

        // Update transaction status to completed
        await db.transaction.update({
          where: { id: transaction.id },
          data: { status: 'COMPLETED' }
        })
        break
    }

    return NextResponse.json({
      success: true,
      data: {
        id: transaction.id,
        amount: transaction.amount,
        price: transaction.price,
        type: transaction.type,
        status: transaction.status,
        fee: transaction.fee,
        createdAt: transaction.createdAt,
        token: {
          id: transaction.token.id,
          symbol: transaction.token.symbol,
          name: transaction.token.name
        },
        fromUser: transaction.from ? {
          id: transaction.from.id,
          name: transaction.from.name,
          avatar: transaction.from.avatar
        } : null,
        toUser: transaction.to ? {
          id: transaction.to.id,
          name: transaction.to.name,
          avatar: transaction.to.avatar
        } : null
      }
    })

  } catch (error) {
    console.error('Error creating transaction:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}