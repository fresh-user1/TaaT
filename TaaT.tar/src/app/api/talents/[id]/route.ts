import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    const talent = await db.talent.findUnique({
      where: { id },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        },
        token: {
          include: {
            holders: {
              include: {
                user: {
                  select: {
                    id: true,
                    name: true,
                    avatar: true
                  }
                }
              },
              orderBy: {
                amount: 'desc'
              },
              take: 10 // Top 10 holders
            },
            investments: {
              include: {
                investor: {
                  select: {
                    id: true,
                    name: true,
                    avatar: true
                  }
                }
              },
              orderBy: {
                createdAt: 'desc'
              },
              take: 10 // Recent investments
            },
            transactions: {
              orderBy: {
                createdAt: 'desc'
              },
              take: 10 // Recent transactions
            }
          }
        },
        projects: {
          orderBy: {
            createdAt: 'desc'
          }
        },
        milestones: {
          orderBy: {
            createdAt: 'desc'
          }
        }
      }
    })

    if (!talent) {
      return NextResponse.json(
        { success: false, error: 'Talent not found' },
        { status: 404 }
      )
    }

    // Transform data
    const transformedTalent = {
      id: talent.id,
      name: talent.user.name,
      email: talent.user.email,
      avatar: talent.user.avatar,
      title: talent.title,
      bio: talent.bio,
      skills: JSON.parse(talent.skills),
      experience: talent.experience,
      website: talent.website,
      twitter: talent.twitter,
      github: talent.github,
      linkedin: talent.linkedin,
      isVerified: talent.isVerified,
      isActive: talent.isActive,
      createdAt: talent.createdAt,
      updatedAt: talent.updatedAt,
      token: talent.token ? {
        id: talent.token.id,
        symbol: talent.token.symbol,
        name: talent.token.name,
        currentPrice: talent.token.currentPrice,
        initialPrice: talent.token.initialPrice,
        totalSupply: talent.token.totalSupply,
        tokensForSale: talent.token.tokensForSale,
        minInvestment: talent.token.minInvestment,
        maxInvestment: talent.token.maxInvestment,
        royaltyPercentage: talent.token.royaltyPercentage,
        consultationHours: talent.token.consultationHours,
        vestingPeriod: talent.token.vestingPeriod,
        status: talent.token.status,
        createdAt: talent.token.createdAt,
        holders: talent.token.holders.map(holder => ({
          id: holder.id,
          user: {
            id: holder.user.id,
            name: holder.user.name,
            avatar: holder.user.avatar
          },
          amount: holder.amount,
          locked: holder.locked,
          createdAt: holder.createdAt
        })),
        investments: talent.token.investments.map(investment => ({
          id: investment.id,
          amount: investment.amount,
          tokens: investment.tokens,
          price: investment.price,
          status: investment.status,
          createdAt: investment.createdAt,
          investor: {
            id: investment.investor.id,
            name: investment.investor.name,
            avatar: investment.investor.avatar
          }
        })),
        transactions: talent.token.transactions.map(transaction => ({
          id: transaction.id,
          amount: transaction.amount,
          price: transaction.price,
          type: transaction.type,
          status: transaction.status,
          fee: transaction.fee,
          createdAt: transaction.createdAt,
          fromUser: transaction.fromUserId ? {
            id: transaction.fromUserId,
            name: transaction.fromUserId // Would need to fetch user details
          } : null,
          toUser: transaction.toUserId ? {
            id: transaction.toUserId,
            name: transaction.toUserId // Would need to fetch user details
          } : null
        })),
        stats: {
          totalHolders: talent.token.holders.length,
          totalInvestments: talent.token.investments.length,
          totalTransactions: talent.token.transactions.length,
          totalRaised: talent.token.investments.reduce((sum, inv) => sum + inv.amount, 0),
          totalTokensSold: talent.token.investments.reduce((sum, inv) => sum + inv.tokens, 0)
        }
      } : null,
      projects: talent.projects.map(project => ({
        id: project.id,
        title: project.title,
        description: project.description,
        status: project.status,
        startDate: project.startDate,
        endDate: project.endDate,
        budget: project.budget,
        createdAt: project.createdAt,
        updatedAt: project.updatedAt
      })),
      milestones: talent.milestones.map(milestone => ({
        id: milestone.id,
        title: milestone.title,
        description: milestone.description,
        achieved: milestone.achieved,
        achievedAt: milestone.achievedAt,
        createdAt: milestone.createdAt,
        updatedAt: milestone.updatedAt
      }))
    }

    return NextResponse.json({
      success: true,
      data: transformedTalent
    })

  } catch (error) {
    console.error('Error fetching talent:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params
    const body = await request.json()
    const {
      title,
      bio,
      skills,
      experience,
      website,
      twitter,
      github,
      linkedin,
      isActive
    } = body

    // Check if talent exists
    const existingTalent = await db.talent.findUnique({
      where: { id }
    })

    if (!existingTalent) {
      return NextResponse.json(
        { success: false, error: 'Talent not found' },
        { status: 404 }
      )
    }

    // Update talent
    const updatedTalent = await db.talent.update({
      where: { id },
      data: {
        ...(title && { title }),
        ...(bio && { bio }),
        ...(skills && { skills: JSON.stringify(skills) }),
        ...(experience && { experience: parseInt(experience) }),
        ...(website !== undefined && { website }),
        ...(twitter !== undefined && { twitter }),
        ...(github !== undefined && { github }),
        ...(linkedin !== undefined && { linkedin }),
        ...(isActive !== undefined && { isActive })
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: {
        id: updatedTalent.id,
        name: updatedTalent.user.name,
        email: updatedTalent.user.email,
        avatar: updatedTalent.user.avatar,
        title: updatedTalent.title,
        bio: updatedTalent.bio,
        skills: JSON.parse(updatedTalent.skills),
        experience: updatedTalent.experience,
        isVerified: updatedTalent.isVerified,
        isActive: updatedTalent.isActive,
        updatedAt: updatedTalent.updatedAt
      }
    })

  } catch (error) {
    console.error('Error updating talent:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id } = params

    // Check if talent exists
    const existingTalent = await db.talent.findUnique({
      where: { id }
    })

    if (!existingTalent) {
      return NextResponse.json(
        { success: false, error: 'Talent not found' },
        { status: 404 }
      )
    }

    // Delete talent (cascade will handle related records)
    await db.talent.delete({
      where: { id }
    })

    return NextResponse.json({
      success: true,
      message: 'Talent deleted successfully'
    })

  } catch (error) {
    console.error('Error deleting talent:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}