import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '12')
    const search = searchParams.get('search') || ''
    const skill = searchParams.get('skill') || ''
    const status = searchParams.get('status') || ''
    const sortBy = searchParams.get('sortBy') || 'popular'

    const skip = (page - 1) * limit

    // Build where clause
    let where: any = {
      isActive: true
    }

    if (search) {
      where.OR = [
        { user: { name: { contains: search, mode: 'insensitive' } } },
        { title: { contains: search, mode: 'insensitive' } },
        { skills: { contains: search, mode: 'insensitive' } }
      ]
    }

    if (skill) {
      where.skills = { contains: skill, mode: 'insensitive' }
    }

    if (status && status !== 'all') {
      where.token = { status: status.toUpperCase() }
    }

    // Build order by
    let orderBy: any = {}
    switch (sortBy) {
      case 'popular':
        orderBy = { token: { holders: { _count: 'desc' } } }
        break
      case 'price_low':
        orderBy = { token: { currentPrice: 'asc' } }
        break
      case 'price_high':
        orderBy = { token: { currentPrice: 'desc' } }
        break
      case 'raised':
        orderBy = { token: { investments: { _sum: { amount: 'desc' } } } }
        break
      default:
        orderBy = { createdAt: 'desc' }
    }

    // Get talents with their tokens
    const talents = await db.talent.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        },
        token: {
          include: {
            _count: {
              select: {
                holders: true,
                investments: true
              }
            },
            investments: {
              select: {
                amount: true
              }
            }
          }
        },
        _count: {
          select: {
            projects: true,
            milestones: true
          }
        }
      },
      skip,
      take: limit,
      orderBy
    })

    // Get total count for pagination
    const total = await db.talent.count({ where })

    // Transform data
    const transformedTalents = talents.map(talent => ({
      id: talent.id,
      name: talent.user.name,
      email: talent.user.email,
      avatar: talent.user.avatar,
      title: talent.title,
      bio: talent.bio,
      skills: JSON.parse(talent.skills),
      experience: talent.experience,
      isVerified: talent.isVerified,
      token: talent.token ? {
        id: talent.token.id,
        symbol: talent.token.symbol,
        name: talent.token.name,
        currentPrice: talent.token.currentPrice,
        initialPrice: talent.token.initialPrice,
        totalSupply: talent.token.totalSupply,
        tokensForSale: talent.token.tokensForSale,
        minInvestment: talent.token.minInvestment,
        maxInvestment: talent.token.maxInvestment,
        royaltyPercentage: talent.token.royaltyPercentage,
        consultationHours: talent.token.consultationHours,
        status: talent.token.status,
        holders: talent.token._count.holders,
        investments: talent.token._count.investments,
        totalRaised: talent.token.investments.reduce((sum, inv) => sum + inv.amount, 0)
      } : null,
      stats: {
        projects: talent._count.projects,
        milestones: talent._count.milestones
      }
    }))

    return NextResponse.json({
      success: true,
      data: transformedTalents,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })

  } catch (error) {
    console.error('Error fetching talents:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      userId,
      title,
      bio,
      skills,
      experience,
      website,
      twitter,
      github,
      linkedin
    } = body

    // Validate required fields
    if (!userId || !title || !bio || !skills || !experience) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check if user already has a talent profile
    const existingTalent = await db.talent.findUnique({
      where: { userId }
    })

    if (existingTalent) {
      return NextResponse.json(
        { success: false, error: 'Talent profile already exists for this user' },
        { status: 400 }
      )
    }

    // Create talent profile
    const talent = await db.talent.create({
      data: {
        userId,
        title,
        bio,
        skills: JSON.stringify(skills),
        experience: parseInt(experience),
        website,
        twitter,
        github,
        linkedin
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: {
        id: talent.id,
        name: talent.user.name,
        email: talent.user.email,
        avatar: talent.user.avatar,
        title: talent.title,
        bio: talent.bio,
        skills: JSON.parse(talent.skills),
        experience: talent.experience,
        isVerified: talent.isVerified,
        createdAt: talent.createdAt
      }
    })

  } catch (error) {
    console.error('Error creating talent:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}