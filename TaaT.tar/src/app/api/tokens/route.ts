import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '12')
    const status = searchParams.get('status') || ''
    const sortBy = searchParams.get('sortBy') || 'createdAt'

    const skip = (page - 1) * limit

    // Build where clause
    let where: any = {}
    if (status && status !== 'all') {
      where.status = status.toUpperCase()
    }

    // Build order by
    let orderBy: any = {}
    switch (sortBy) {
      case 'price_high':
        orderBy = { currentPrice: 'desc' }
        break
      case 'price_low':
        orderBy = { currentPrice: 'asc' }
        break
      case 'market_cap':
        orderBy = { currentPrice: 'desc' } // Simplified - would need totalSupply * currentPrice
        break
      case 'volume':
        orderBy = { transactions: { _count: 'desc' } }
        break
      default:
        orderBy = { createdAt: 'desc' }
    }

    const tokens = await db.token.findMany({
      where,
      include: {
        talent: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          }
        },
        _count: {
          select: {
            holders: true,
            investments: true,
            transactions: true
          }
        },
        investments: {
          select: {
            amount: true,
            tokens: true
          }
        }
      },
      skip,
      take: limit,
      orderBy
    })

    const total = await db.token.count({ where })

    // Transform data
    const transformedTokens = tokens.map(token => ({
      id: token.id,
      symbol: token.symbol,
      name: token.name,
      currentPrice: token.currentPrice,
      initialPrice: token.initialPrice,
      priceChange: ((token.currentPrice - token.initialPrice) / token.initialPrice) * 100,
      totalSupply: token.totalSupply,
      tokensForSale: token.tokensForSale,
      tokensSold: token.investments.reduce((sum, inv) => sum + inv.tokens, 0),
      minInvestment: token.minInvestment,
      maxInvestment: token.maxInvestment,
      royaltyPercentage: token.royaltyPercentage,
      consultationHours: token.consultationHours,
      vestingPeriod: token.vestingPeriod,
      status: token.status,
      createdAt: token.createdAt,
      talent: {
        id: token.talent.id,
        name: token.talent.user.name,
        avatar: token.talent.user.avatar,
        title: token.talent.title,
        skills: JSON.parse(token.talent.skills),
        isVerified: token.talent.isVerified
      },
      stats: {
        holders: token._count.holders,
        investments: token._count.investments,
        transactions: token._count.transactions,
        totalRaised: token.investments.reduce((sum, inv) => sum + inv.amount, 0),
        marketCap: token.totalSupply * token.currentPrice
      }
    }))

    return NextResponse.json({
      success: true,
      data: transformedTokens,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })

  } catch (error) {
    console.error('Error fetching tokens:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      talentId,
      symbol,
      name,
      totalSupply,
      initialPrice,
      tokensForSale,
      minInvestment,
      maxInvestment,
      royaltyPercentage,
      consultationHours,
      vestingPeriod
    } = body

    // Validate required fields
    if (!talentId || !symbol || !name || !totalSupply || !initialPrice || !tokensForSale) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Check if talent exists
    const talent = await db.talent.findUnique({
      where: { id: talentId }
    })

    if (!talent) {
      return NextResponse.json(
        { success: false, error: 'Talent not found' },
        { status: 404 }
      )
    }

    // Check if token already exists for this talent
    const existingToken = await db.token.findUnique({
      where: { talentId }
    })

    if (existingToken) {
      return NextResponse.json(
        { success: false, error: 'Token already exists for this talent' },
        { status: 400 }
      )
    }

    // Check if symbol is unique
    const symbolExists = await db.token.findUnique({
      where: { symbol: symbol.toUpperCase() }
    })

    if (symbolExists) {
      return NextResponse.json(
        { success: false, error: 'Token symbol already exists' },
        { status: 400 }
      )
    }

    // Create token
    const token = await db.token.create({
      data: {
        talentId,
        symbol: symbol.toUpperCase(),
        name,
        totalSupply: parseInt(totalSupply),
        initialPrice: parseFloat(initialPrice),
        currentPrice: parseFloat(initialPrice),
        tokensForSale: parseInt(tokensForSale),
        minInvestment: parseFloat(minInvestment) || 50,
        maxInvestment: parseFloat(maxInvestment) || 10000,
        royaltyPercentage: parseFloat(royaltyPercentage) || 5,
        consultationHours: parseInt(consultationHours) || 10,
        vestingPeriod: parseInt(vestingPeriod) || 36,
        status: 'PENDING'
      },
      include: {
        talent: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          }
        }
      }
    })

    return NextResponse.json({
      success: true,
      data: {
        id: token.id,
        symbol: token.symbol,
        name: token.name,
        currentPrice: token.currentPrice,
        initialPrice: token.initialPrice,
        totalSupply: token.totalSupply,
        tokensForSale: token.tokensForSale,
        minInvestment: token.minInvestment,
        maxInvestment: token.maxInvestment,
        royaltyPercentage: token.royaltyPercentage,
        consultationHours: token.consultationHours,
        vestingPeriod: token.vestingPeriod,
        status: token.status,
        createdAt: token.createdAt,
        talent: {
          id: token.talent.id,
          name: token.talent.user.name,
          avatar: token.talent.user.avatar,
          title: token.talent.title
        }
      }
    })

  } catch (error) {
    console.error('Error creating token:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}