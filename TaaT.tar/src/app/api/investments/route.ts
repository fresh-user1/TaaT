import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '12')
    const tokenId = searchParams.get('tokenId')
    const investorId = searchParams.get('investorId')
    const status = searchParams.get('status') || ''

    const skip = (page - 1) * limit

    // Build where clause
    let where: any = {}
    if (tokenId) where.tokenId = tokenId
    if (investorId) where.investorId = investorId
    if (status && status !== 'all') where.status = status.toUpperCase()

    const investments = await db.investment.findMany({
      where,
      include: {
        token: {
          include: {
            talent: {
              include: {
                user: {
                  select: {
                    id: true,
                    name: true,
                    avatar: true
                  }
                }
              }
            }
          }
        },
        investor: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      },
      skip,
      take: limit,
      orderBy: { createdAt: 'desc' }
    })

    const total = await db.investment.count({ where })

    // Transform data
    const transformedInvestments = investments.map(investment => ({
      id: investment.id,
      amount: investment.amount,
      tokens: investment.tokens,
      price: investment.price,
      status: investment.status,
      createdAt: investment.createdAt,
      updatedAt: investment.updatedAt,
      token: {
        id: investment.token.id,
        symbol: investment.token.symbol,
        name: investment.token.name,
        currentPrice: investment.token.currentPrice,
        talent: {
          id: investment.token.talent.id,
          name: investment.token.talent.user.name,
          avatar: investment.token.talent.user.avatar,
          title: investment.token.talent.title
        }
      },
      investor: {
        id: investment.investor.id,
        name: investment.investor.name,
        email: investment.investor.email,
        avatar: investment.investor.avatar
      }
    }))

    return NextResponse.json({
      success: true,
      data: transformedInvestments,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })

  } catch (error) {
    console.error('Error fetching investments:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const {
      tokenId,
      investorId,
      amount
    } = body

    // Validate required fields
    if (!tokenId || !investorId || !amount) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Get token details
    const token = await db.token.findUnique({
      where: { id: tokenId },
      include: {
        talent: true
      }
    })

    if (!token) {
      return NextResponse.json(
        { success: false, error: 'Token not found' },
        { status: 404 }
      )
    }

    // Check if token is active
    if (token.status !== 'ACTIVE') {
      return NextResponse.json(
        { success: false, error: 'Token is not active for investment' },
        { status: 400 }
      )
    }

    // Validate investment amount
    if (amount < token.minInvestment) {
      return NextResponse.json(
        { 
          success: false, 
          error: `Minimum investment amount is $${token.minInvestment}` 
        },
        { status: 400 }
      )
    }

    if (amount > token.maxInvestment) {
      return NextResponse.json(
        { 
          success: false, 
          error: `Maximum investment amount is $${token.maxInvestment}` 
        },
        { status: 400 }
      )
    }

    // Calculate tokens to receive
    const tokensToReceive = Math.floor(amount / token.currentPrice)

    // Check if enough tokens are available
    const totalSold = await db.investment.aggregate({
      where: { 
        tokenId, 
        status: 'COMPLETED' 
      },
      _sum: { tokens: true }
    })

    const availableTokens = token.tokensForSale - (totalSold._sum.tokens || 0)

    if (tokensToReceive > availableTokens) {
      return NextResponse.json(
        { 
          success: false, 
          error: `Not enough tokens available. Only ${availableTokens} tokens left` 
        },
        { status: 400 }
      )
    }

    // Create investment
    const investment = await db.investment.create({
      data: {
        tokenId,
        investorId,
        amount: parseFloat(amount),
        tokens: tokensToReceive,
        price: token.currentPrice,
        status: 'PENDING'
      },
      include: {
        token: {
          include: {
            talent: {
              include: {
                user: {
                  select: {
                    id: true,
                    name: true,
                    avatar: true
                  }
                }
              }
            }
          }
        },
        investor: {
          select: {
            id: true,
            name: true,
            email: true,
            avatar: true
          }
        }
      }
    })

    // Create token holder record
    await db.tokenHolder.upsert({
      where: {
        tokenId_userId: {
          tokenId,
          userId: investorId
        }
      },
      update: {
        amount: {
          increment: tokensToReceive
        },
        locked: {
          increment: Math.floor(tokensToReceive * 0.8) // 80% locked for vesting
        }
      },
      create: {
        tokenId,
        userId: investorId,
        amount: tokensToReceive,
        locked: Math.floor(tokensToReceive * 0.8) // 80% locked for vesting
      }
    })

    // Create transaction record
    await db.transaction.create({
      data: {
        tokenId,
        toUserId: investorId,
        amount: tokensToReceive,
        price: token.currentPrice,
        type: 'PURCHASE',
        status: 'COMPLETED',
        fee: amount * 0.02 // 2% transaction fee
      }
    })

    // Update token status if all tokens are sold
    const newTotalSold = (totalSold._sum.tokens || 0) + tokensToReceive
    if (newTotalSold >= token.tokensForSale) {
      await db.token.update({
        where: { id: tokenId },
        data: { status: 'COMPLETED' }
      })
    }

    return NextResponse.json({
      success: true,
      data: {
        id: investment.id,
        amount: investment.amount,
        tokens: investment.tokens,
        price: investment.price,
        status: investment.status,
        createdAt: investment.createdAt,
        token: {
          id: investment.token.id,
          symbol: investment.token.symbol,
          name: investment.token.name,
          currentPrice: investment.token.currentPrice,
          talent: {
            id: investment.token.talent.id,
            name: investment.token.talent.user.name,
            avatar: investment.token.talent.user.avatar,
            title: investment.token.talent.title
          }
        },
        investor: {
          id: investment.investor.id,
          name: investment.investor.name,
          email: investment.investor.email,
          avatar: investment.investor.avatar
        }
      }
    })

  } catch (error) {
    console.error('Error creating investment:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}